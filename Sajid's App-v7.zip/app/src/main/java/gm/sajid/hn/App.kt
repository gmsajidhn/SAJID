package gm.sajid.hn

import android.app.Application

// প্রসেস চালু হওয়ার প্রথমেই (অ্যাপ খুললে, রিবুটে বা আপডেটের পরে) আপডেট-চেক চলে
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        try { Updater.check(this) } catch (e: Exception) { }
    }
}
