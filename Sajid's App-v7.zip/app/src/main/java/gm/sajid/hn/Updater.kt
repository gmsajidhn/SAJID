package gm.sajid.hn

import android.content.Context
import android.content.Intent

// অ্যাপ আপডেট (একই ভার্সন নম্বর হলেও) হলে প্রথমবার চালু হওয়ার সময় একবার "সেলফ-হিল" চলে:
// পুরোনো ভার্সনের আটকে থাকা অবস্থা মুছে সব ফাংশন নতুন করে ঠিকঠাক চালু করে — আনইনস্টল লাগে না।
// সেটিংস, রুটিন, রিংটোন, ডাটা কিছুই মোছে না।
object Updater {
    @Synchronized
    fun check(c: Context) {
        val ctx = c.applicationContext
        val sp = ctx.getSharedPreferences("updater", Context.MODE_PRIVATE)
        // lastUpdateTime প্রতিবার ইনস্টলে বদলায়, ভার্সন নম্বর একই থাকলেও
        val stamp = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime } catch (e: Exception) { 0L }
        if (sp.getLong("stamp", -1L) == stamp) return
        sp.edit().putLong("stamp", stamp).apply()
        heal(ctx)
    }

    private fun heal(ctx: Context) {
        // 1) পারমিশন চাওয়ার গোনা রিসেট — আগে ৩ বার চাওয়া হয়ে গেলে আর চাইত না, তাই ভাসমান টাইমার আটকে থাকত
        try { ctx.getSharedPreferences("perm", Context.MODE_PRIVATE).edit().clear().apply() } catch (e: Exception) { }

        // 2) ভাসমান টাইমার: পুরোনো সার্ভিস/অবস্থা পরিষ্কার, যাতে পরের টাইমার চালুতেই আবার চালু হয়
        try { ctx.stopService(Intent(ctx, FloatingTimerService::class.java)) } catch (e: Exception) { }
        FloatingTimerService.running = false
        FloatingTimerService.lastTick = 0L
        TimerState.clear()
        TimerState.shownKind = ""
        TimerState.ignoreUntil = 0L

        // 3) চলতে থাকা অ্যালার্ম সার্ভিস আটকে থাকলে থামানো (শুধু যদি আগের ভার্সনের বাজা অবস্থা থেকে যায়)
        try { ctx.stopService(Intent(ctx, AlarmService::class.java)) } catch (e: Exception) { }

        // 4) সব অ্যালার্ম নতুন করে সেট (আপডেটে সিস্টেম পুরোনো অ্যালার্ম মুছে ফেলে)
        try { Scheduler.rescheduleAll(ctx) } catch (e: Exception) { }
    }
}
