package gm.sajid.hn

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject

// অ্যাপের সব ডাটা (রুটিন, সাবজেক্ট, হিস্টোরি, সেটিং, রিংটোন, ব্রাউজারের বুকমার্ক/হিস্টোরি/শর্টকাট) একটা ফাইলে এক্সপোর্ট / সেখান থেকে ইম্পোর্ট।
// পাসওয়ার্ড ও লগইন-কুকি এতে থাকে না (ফোনের সিকিউরিটি কী-এর সাথে বাঁধা, অন্য অ্যাপে চলে না)।
object BackupManager {
    const val FORMAT = "SajidStudyTrackerBackup"
    private const val MAX_FILES_BYTES = 40L * 1024 * 1024

    // কোন কোন সেটিং-কী ব্যাকআপে যাবে
    private fun alarmKey(k: String) = k in setOf("ringMin", "snoozeMin", "snoozeMax", "defVib", "defVol", "ringtone", "history")
    private fun browserKey(k: String) =
        k == "history" || k.startsWith("history_") || k == "bookmarks" || k.startsWith("bookmarks_") ||
        k == "shortcuts" || k.startsWith("shortcuts_") ||
        k in setOf("profiles", "ntpTitle", "ntpColor", "ntpBg", "engine", "theme")
    // ফাইল: রিংটোন, প্রোফাইল ছবি, শর্টকাট আইকন, হোম ব্যাকগ্রাউন্ড ছবি
    private fun backupFile(n: String) = Regex("^(ring_.*|profile_.*\\.png|sc_.*\\.png|ntp_bg\\.jpg)$").matches(n)
    // চলমান টাইমারের অবস্থা অন্য অ্যাপে নেওয়া হয় না
    private fun skipLocal(k: String) = k.endsWith("_running_state")

    private fun dumpPrefs(c: Context, name: String, keep: (String) -> Boolean): JSONArray {
        val out = JSONArray()
        val sp = c.getSharedPreferences(name, Context.MODE_PRIVATE)
        for ((k, v) in sp.all) {
            if (!keep(k) || v == null) continue
            val o = JSONObject().put("k", k)
            when (v) {
                is String -> o.put("t", "s").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Boolean -> o.put("t", "b").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                is Set<*> -> o.put("t", "ss").put("v", JSONArray(v.map { it.toString() }))
                else -> continue
            }
            out.put(o)
        }
        return out
    }

    private fun restorePrefs(c: Context, name: String, keep: (String) -> Boolean, arr: JSONArray?) {
        val sp = c.getSharedPreferences(name, Context.MODE_PRIVATE)
        val ed = sp.edit()
        for (k in sp.all.keys) if (keep(k)) ed.remove(k)
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i); val k = o.getString("k")
            if (!keep(k)) continue
            when (o.getString("t")) {
                "s" -> ed.putString(k, o.getString("v"))
                "i" -> ed.putInt(k, o.getInt("v"))
                "l" -> ed.putLong(k, o.getLong("v"))
                "b" -> ed.putBoolean(k, o.getBoolean("v"))
                "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                "ss" -> { val a = o.getJSONArray("v"); ed.putStringSet(k, HashSet<String>().apply { for (j in 0 until a.length()) add(a.getString(j)) }) }
            }
        }
        ed.commit()
    }

    // localStorageJson = অ্যাপের পেজের সব localStorage (JSON অবজেক্ট স্ট্রিং)
    fun build(c: Context, localStorageJson: String): String {
        val root = JSONObject()
        root.put("app", FORMAT).put("version", 1).put("createdAt", System.currentTimeMillis())
        val ls = JSONObject(localStorageJson)
        val keys = ls.keys().asSequence().toList()
        keys.filter { skipLocal(it) }.forEach { ls.remove(it) }
        root.put("local", ls)
        root.put("alarm", dumpPrefs(c, "alarm", ::alarmKey))
        root.put("browser", dumpPrefs(c, "browser", ::browserKey))
        val files = JSONObject()
        var total = 0L
        c.filesDir.listFiles()?.filter { it.isFile && backupFile(it.name) }?.forEach { f ->
            if (total + f.length() <= MAX_FILES_BYTES) {
                total += f.length()
                files.put(f.name, Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
            }
        }
        root.put("files", files)
        return root.toString()
    }

    // ফাইল ঠিক আছে কিনা (ইম্পোর্টের আগে)
    fun validate(text: String): Boolean = try {
        val o = JSONObject(text); o.optString("app") == FORMAT && o.has("local")
    } catch (e: Exception) { false }

    // নেটিভ অংশ (সেটিং + ফাইল) বসায়; পেজের localStorage এর JSON স্ট্রিং ফেরত দেয় (পেজে বসানোর জন্য)
    fun applyNative(c: Context, text: String): String {
        val o = JSONObject(text)
        restorePrefs(c, "alarm", ::alarmKey, o.optJSONArray("alarm"))
        restorePrefs(c, "browser", ::browserKey, o.optJSONArray("browser"))
        c.filesDir.listFiles()?.filter { it.isFile && backupFile(it.name) }?.forEach { it.delete() }
        val files = o.optJSONObject("files")
        if (files != null) for (n in files.keys()) {
            if (!backupFile(n) || n.contains("/") || n.contains("..")) continue
            try { java.io.File(c.filesDir, n).writeBytes(Base64.decode(files.getString(n), Base64.DEFAULT)) } catch (e: Exception) { }
        }
        return o.getJSONObject("local").toString()
    }
}
